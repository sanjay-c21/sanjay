package com.smartattendance.controller;

import com.smartattendance.model.AttendanceSession;
import com.smartattendance.model.Subject;
import com.smartattendance.model.Teacher;
import com.smartattendance.service.AttendanceService;
import com.smartattendance.service.SubjectService;
import com.smartattendance.service.TeacherService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/teachers")
@CrossOrigin(origins = "*")
public class TeacherController {

    private final TeacherService teacherService;
    private final SubjectService subjectService;
    private final AttendanceService attendanceService;

    public TeacherController(TeacherService teacherService,
                             SubjectService subjectService,
                             AttendanceService attendanceService) {
        this.teacherService = teacherService;
        this.subjectService = subjectService;
        this.attendanceService = attendanceService;
    }

    @GetMapping
    public List<Teacher> getAllTeachers() {
        return teacherService.getAllTeachers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Teacher> getTeacher(@PathVariable Long id) {
        return teacherService.getTeacherById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        String email = credentials.get("email");
        String password = credentials.get("password");

        return teacherService.authenticate(email, password)
                .map(teacher -> ResponseEntity.ok(Map.of(
                        "success", true,
                        "teacherId", teacher.getId(),
                        "name", teacher.getName(),
                        "email", teacher.getEmail(),
                        "department", teacher.getDepartment()
                )))
                .orElse(ResponseEntity.status(401).body(Map.of(
                        "success", false,
                        "error", "Invalid email or password."
                )));
    }

    @GetMapping("/{id}/subjects")
    public List<Subject> getTeacherSubjects(@PathVariable Long id) {
        return subjectService.getSubjectsByTeacherId(id);
    }

    @GetMapping("/{id}/sessions")
    public List<AttendanceSession> getTeacherSessions(@PathVariable Long id) {
        return attendanceService.getTeacherSessions(id);
    }
}
