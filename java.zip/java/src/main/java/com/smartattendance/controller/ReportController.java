package com.smartattendance.controller;

import com.smartattendance.service.ReportService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    /**
     * Download Attendance Report as CSV
     */
    @GetMapping("/sessions/{sessionId}/csv")
    public ResponseEntity<byte[]> downloadCsv(@PathVariable Long sessionId) {
        byte[] csvData = reportService.generateCsv(sessionId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"attendance_session_" + sessionId + ".csv\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(csvData);
    }

    /**
     * Download Attendance Report as Excel (.xlsx)
     */
    @GetMapping("/sessions/{sessionId}/excel")
    public ResponseEntity<byte[]> downloadExcel(@PathVariable Long sessionId) {
        try {
            byte[] xlsxData = reportService.generateExcel(sessionId);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"attendance_session_" + sessionId + ".xlsx\"")
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(xlsxData);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Download Attendance Report as PDF
     */
    @GetMapping("/sessions/{sessionId}/pdf")
    public ResponseEntity<byte[]> downloadPdf(@PathVariable Long sessionId) {
        try {
            byte[] pdfData = reportService.generatePdf(sessionId);
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"attendance_session_" + sessionId + ".pdf\"")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdfData);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
