package com.smartattendance.controller;

import com.smartattendance.dto.ManualAttendanceDto;
import com.smartattendance.dto.ScanRequest;
import com.smartattendance.dto.ScanResponse;
import com.smartattendance.model.Attendance;
import com.smartattendance.service.AttendanceService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/attendance")
@CrossOrigin(origins = "*")
public class AttendanceController {

    private final AttendanceService attendanceService;

    public AttendanceController(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    /**
     * Core Anti-Proxy QR Code Scanning & Attendance Verification Endpoint
     */
    @PostMapping("/scan")
    public ResponseEntity<ScanResponse> scanQr(@RequestBody ScanRequest request, HttpServletRequest servletRequest) {
        String clientIp = servletRequest.getRemoteAddr();
        String userAgent = servletRequest.getHeader("User-Agent");

        ScanResponse response = attendanceService.markAttendance(
                request.getQrToken(),
                request.getSessionToken(),
                clientIp,
                userAgent
        );

        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * Fetch all attendance records for a specific session
     */
    @GetMapping("/session/{sessionId}")
    public List<Attendance> getAttendanceForSession(@PathVariable Long sessionId) {
        return attendanceService.getAttendanceForSession(sessionId);
    }

    /**
     * Manual attendance override / correction by teacher
     */
    @PostMapping("/manual")
    public ResponseEntity<?> manualUpdate(@RequestBody ManualAttendanceDto dto) {
        try {
            Attendance updated = attendanceService.updateAttendanceStatus(
                    dto.getStudentId(),
                    dto.getSessionId(),
                    dto.getStatus(),
                    dto.getRemarks()
            );
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
