package com.smartattendance.controller;

import com.smartattendance.dto.AttendanceStatsDto;
import com.smartattendance.dto.SessionCreateRequest;
import com.smartattendance.model.AttendanceSession;
import com.smartattendance.service.AttendanceService;
import com.smartattendance.service.QrCodeService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sessions")
@CrossOrigin(origins = "*")
public class AttendanceSessionController {

    private final AttendanceService attendanceService;
    private final QrCodeService qrCodeService;

    public AttendanceSessionController(AttendanceService attendanceService, QrCodeService qrCodeService) {
        this.attendanceService = attendanceService;
        this.qrCodeService = qrCodeService;
    }

    @GetMapping
    public List<AttendanceSession> getAllSessions() {
        return attendanceService.getAllSessions();
    }

    @PostMapping("/start")
    public ResponseEntity<?> startSession(@RequestBody SessionCreateRequest request) {
        try {
            AttendanceSession session = attendanceService.startSession(
                    request.getSubjectId(),
                    request.getTeacherId(),
                    request.getDurationMinutes() != null ? request.getDurationMinutes() : 15,
                    request.getTopic()
            );
            return ResponseEntity.status(HttpStatus.CREATED).body(session);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/{id}/close")
    public ResponseEntity<?> closeSession(@PathVariable Long id) {
        try {
            AttendanceSession closed = attendanceService.closeSession(id);
            return ResponseEntity.ok(closed);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<AttendanceSession> getSession(@PathVariable Long id) {
        return attendanceService.getSessionById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/stats")
    public ResponseEntity<?> getSessionStats(@PathVariable Long id) {
        try {
            AttendanceStatsDto stats = attendanceService.getSessionStats(id);
            return ResponseEntity.ok(stats);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Get Session QR Code (can be projected on classroom screen for students to scan)
     */
    @GetMapping(value = "/{id}/qr/image", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> getSessionQrImage(@PathVariable Long id,
                                                    @RequestParam(defaultValue = "400") int size) {
        return attendanceService.getSessionById(id)
                .map(session -> {
                    try {
                        byte[] png = qrCodeService.generateQrCodePng(session.getSessionToken(), size, size);
                        return ResponseEntity.ok()
                                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + session.getSessionToken() + "-QR.png\"")
                                .contentType(MediaType.IMAGE_PNG)
                                .body(png);
                    } catch (Exception e) {
                        return ResponseEntity.internalServerError().<byte[]>build();
                    }
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/qr")
    public ResponseEntity<?> getSessionQrBase64(@PathVariable Long id) {
        return attendanceService.getSessionById(id)
                .map(session -> {
                    String base64 = qrCodeService.generateQrCodeBase64(session.getSessionToken(), 400, 400);
                    Map<String, Object> resp = new HashMap<>();
                    resp.put("sessionId", session.getId());
                    resp.put("sessionToken", session.getSessionToken());
                    resp.put("subject", session.getSubject().getSubjectName());
                    resp.put("status", session.getStatus().name());
                    resp.put("qrDataUrl", base64);
                    return ResponseEntity.ok(resp);
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
