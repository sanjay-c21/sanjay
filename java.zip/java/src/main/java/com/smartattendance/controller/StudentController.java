package com.smartattendance.controller;

import com.smartattendance.dto.StudentSummaryDto;
import com.smartattendance.model.Student;
import com.smartattendance.service.AttendanceService;
import com.smartattendance.service.QrCodeService;
import com.smartattendance.service.StudentService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = "*")
public class StudentController {

    private final StudentService studentService;
    private final QrCodeService qrCodeService;
    private final AttendanceService attendanceService;

    public StudentController(StudentService studentService, QrCodeService qrCodeService, AttendanceService attendanceService) {
        this.studentService = studentService;
        this.qrCodeService = qrCodeService;
        this.attendanceService = attendanceService;
    }

    @GetMapping
    public List<Student> getStudents(@RequestParam(required = false) String department) {
        if (department != null && !department.trim().isEmpty()) {
            return studentService.getStudentsByDepartment(department);
        }
        return studentService.getAllStudents();
    }

    @PostMapping
    public ResponseEntity<?> registerStudent(@RequestBody Student student) {
        try {
            Student saved = studentService.registerStudent(student);
            return ResponseEntity.status(HttpStatus.CREATED).body(saved);
        } catch (IllegalArgumentException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudent(@PathVariable Long id) {
        return studentService.getStudentById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/by-reg/{regNo}")
    public ResponseEntity<Student> getByRegNo(@PathVariable String regNo) {
        return studentService.getStudentByRegisterNumber(regNo)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateStudent(@PathVariable Long id, @RequestBody Student updated) {
        try {
            return ResponseEntity.ok(studentService.updateStudent(id, updated));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return ResponseEntity.ok(Map.of("message", "Student deleted successfully"));
    }

    @PostMapping("/{id}/regenerate-qr")
    public ResponseEntity<Student> regenerateQr(@PathVariable Long id) {
        return ResponseEntity.ok(studentService.regenerateQrToken(id));
    }

    /**
     * Get QR code as raw PNG image
     */
    @GetMapping(value = "/{id}/qr/image", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> getQrImage(@PathVariable Long id,
                                             @RequestParam(defaultValue = "350") int size) {
        return studentService.getStudentById(id)
                .map(student -> {
                    try {
                        byte[] png = qrCodeService.generateQrCodePng(student.getQrToken(), size, size);
                        return ResponseEntity.ok()
                                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + student.getRegisterNumber() + "-QR.png\"")
                                .contentType(MediaType.IMAGE_PNG)
                                .body(png);
                    } catch (Exception e) {
                        return ResponseEntity.internalServerError().<byte[]>build();
                    }
                })
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Get QR code as Base64 JSON
     */
    @GetMapping("/{id}/qr")
    public ResponseEntity<?> getQrBase64(@PathVariable Long id) {
        return studentService.getStudentById(id)
                .map(student -> {
                    String base64 = qrCodeService.generateQrCodeBase64(student.getQrToken());
                    Map<String, Object> resp = new HashMap<>();
                    resp.put("studentId", student.getId());
                    resp.put("registerNumber", student.getRegisterNumber());
                    resp.put("name", student.getName());
                    resp.put("department", student.getDepartment());
                    resp.put("qrToken", student.getQrToken());
                    resp.put("qrDataUrl", base64);
                    return ResponseEntity.ok(resp);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Get Student Attendance Summary & Subject Breakdown
     */
    @GetMapping("/{id}/summary")
    public ResponseEntity<StudentSummaryDto> getStudentSummary(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(attendanceService.getStudentSummary(id));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
