package com.smartattendance.controller;

import com.smartattendance.model.Subject;
import com.smartattendance.model.Teacher;
import com.smartattendance.repository.AttendanceRepository;
import com.smartattendance.repository.AttendanceSessionRepository;
import com.smartattendance.repository.StudentRepository;
import com.smartattendance.repository.TeacherRepository;
import com.smartattendance.service.SubjectService;
import com.smartattendance.service.TeacherService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final StudentRepository studentRepository;
    private final TeacherRepository teacherRepository;
    private final AttendanceSessionRepository sessionRepository;
    private final AttendanceRepository attendanceRepository;
    private final TeacherService teacherService;
    private final SubjectService subjectService;

    public AdminController(StudentRepository studentRepository,
                           TeacherRepository teacherRepository,
                           AttendanceSessionRepository sessionRepository,
                           AttendanceRepository attendanceRepository,
                           TeacherService teacherService,
                           SubjectService subjectService) {
        this.studentRepository = studentRepository;
        this.teacherRepository = teacherRepository;
        this.sessionRepository = sessionRepository;
        this.attendanceRepository = attendanceRepository;
        this.teacherService = teacherService;
        this.subjectService = subjectService;
    }

    /**
     * Overall College & System Statistics
     */
    @GetMapping("/stats")
    public Map<String, Object> getSystemStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalStudents", studentRepository.count());
        stats.put("totalTeachers", teacherRepository.count());
        stats.put("totalSubjects", subjectService.getAllSubjects().size());
        stats.put("totalSessions", sessionRepository.count());
        stats.put("totalAttendanceMarked", attendanceRepository.count());
        return stats;
    }

    @PostMapping("/teachers")
    public ResponseEntity<?> addTeacher(@RequestBody Teacher teacher) {
        if (teacherRepository.existsByEmail(teacher.getEmail())) {
            return ResponseEntity.badRequest().body(Map.of("error", "Email already exists: " + teacher.getEmail()));
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(teacherService.saveTeacher(teacher));
    }

    @PostMapping("/subjects")
    public ResponseEntity<?> addSubject(@RequestBody Map<String, Object> req) {
        try {
            String code = (String) req.get("subjectCode");
            String name = (String) req.get("subjectName");
            String department = (String) req.get("department");
            Long teacherId = Long.valueOf(req.get("teacherId").toString());

            Teacher teacher = teacherRepository.findById(teacherId)
                    .orElseThrow(() -> new IllegalArgumentException("Teacher not found with ID: " + teacherId));

            Subject subject = subjectService.createSubject(code, name, department, teacher);
            return ResponseEntity.status(HttpStatus.CREATED).body(subject);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/subjects")
    public ResponseEntity<?> getAllSubjects() {
        return ResponseEntity.ok(subjectService.getAllSubjects());
    }
}
