package com.smartattendance.repository;

import com.smartattendance.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    Optional<Student> findByRegisterNumber(String registerNumber);

    Optional<Student> findByQrToken(String qrToken);

    List<Student> findByDepartment(String department);

    List<Student> findByDepartmentAndYearAndSection(String department, Integer year, String section);

    boolean existsByRegisterNumber(String registerNumber);

    boolean existsByQrToken(String qrToken);
}
