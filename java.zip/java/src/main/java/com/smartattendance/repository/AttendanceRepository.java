package com.smartattendance.repository;

import com.smartattendance.model.Attendance;
import com.smartattendance.model.AttendanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {

    Optional<Attendance> findByStudentIdAndSessionId(Long studentId, Long sessionId);

    boolean existsByStudentIdAndSessionId(Long studentId, Long sessionId);

    List<Attendance> findBySessionId(Long sessionId);

    List<Attendance> findBySessionIdOrderByMarkedAtDesc(Long sessionId);

    List<Attendance> findByStudentIdOrderByMarkedAtDesc(Long studentId);

    long countBySessionId(Long sessionId);

    long countBySessionIdAndStatus(Long sessionId, AttendanceStatus status);

    long countByStudentIdAndStatus(Long studentId, AttendanceStatus status);

    @Query("SELECT COUNT(a) FROM Attendance a WHERE a.student.id = :studentId AND a.session.subject.id = :subjectId AND a.status = :status")
    long countByStudentAndSubjectAndStatus(@Param("studentId") Long studentId, @Param("subjectId") Long subjectId, @Param("status") AttendanceStatus status);

    @Query("SELECT a FROM Attendance a WHERE a.session.subject.id = :subjectId ORDER BY a.markedAt DESC")
    List<Attendance> findBySubjectId(@Param("subjectId") Long subjectId);
}
