package com.smartattendance.repository;

import com.smartattendance.model.Subject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SubjectRepository extends JpaRepository<Subject, Long> {

    Optional<Subject> findBySubjectCode(String subjectCode);

    List<Subject> findByTeacherId(Long teacherId);

    List<Subject> findByDepartment(String department);

    boolean existsBySubjectCode(String subjectCode);
}
