package com.smartattendance.repository;

import com.smartattendance.model.AttendanceSession;
import com.smartattendance.model.SessionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceSessionRepository extends JpaRepository<AttendanceSession, Long> {

    Optional<AttendanceSession> findBySessionToken(String sessionToken);

    List<AttendanceSession> findByTeacherIdOrderByStartTimeDesc(Long teacherId);

    List<AttendanceSession> findBySubjectIdOrderByStartTimeDesc(Long subjectId);

    List<AttendanceSession> findByStatus(SessionStatus status);

    List<AttendanceSession> findBySubjectIdAndStatus(Long subjectId, SessionStatus status);

    List<AttendanceSession> findAllByOrderByStartTimeDesc();

    long countBySubjectId(Long subjectId);
}
