package com.smartattendance.dto;

import com.smartattendance.model.AttendanceStatus;

public class ScanResponse {

    private boolean success;
    private String message;
    private String studentName;
    private String registerNumber;
    private String department;
    private String subjectName;
    private String markedTime;
    private AttendanceStatus status;
    private String errorCode;

    public ScanResponse() {
    }

    public static ScanResponse ok(String message, String studentName, String regNo, String dept, String subject, String time, AttendanceStatus status) {
        ScanResponse resp = new ScanResponse();
        resp.setSuccess(true);
        resp.setMessage(message);
        resp.setStudentName(studentName);
        resp.setRegisterNumber(regNo);
        resp.setDepartment(dept);
        resp.setSubjectName(subject);
        resp.setMarkedTime(time);
        resp.setStatus(status);
        return resp;
    }

    public static ScanResponse fail(String message, String errorCode) {
        ScanResponse resp = new ScanResponse();
        resp.setSuccess(false);
        resp.setMessage(message);
        resp.setErrorCode(errorCode);
        return resp;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getRegisterNumber() {
        return registerNumber;
    }

    public void setRegisterNumber(String registerNumber) {
        this.registerNumber = registerNumber;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getMarkedTime() {
        return markedTime;
    }

    public void setMarkedTime(String markedTime) {
        this.markedTime = markedTime;
    }

    public AttendanceStatus getStatus() {
        return status;
    }

    public void setStatus(AttendanceStatus status) {
        this.status = status;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
