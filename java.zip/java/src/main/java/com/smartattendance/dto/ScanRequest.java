package com.smartattendance.dto;

public class ScanRequest {

    private String qrToken;
    private String sessionToken;
    private String clientTimestamp;

    public ScanRequest() {
    }

    public ScanRequest(String qrToken, String sessionToken) {
        this.qrToken = qrToken;
        this.sessionToken = sessionToken;
    }

    public String getQrToken() {
        return qrToken;
    }

    public void setQrToken(String qrToken) {
        this.qrToken = qrToken;
    }

    public String getSessionToken() {
        return sessionToken;
    }

    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }

    public String getClientTimestamp() {
        return clientTimestamp;
    }

    public void setClientTimestamp(String clientTimestamp) {
        this.clientTimestamp = clientTimestamp;
    }
}
