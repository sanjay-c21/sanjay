package com.smartattendance.dto;

import com.smartattendance.model.AttendanceStatus;

public class ManualAttendanceDto {

    private Long studentId;
    private Long sessionId;
    private AttendanceStatus status = AttendanceStatus.PRESENT;
    private String remarks;

    public ManualAttendanceDto() {
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public Long getSessionId() {
        return sessionId;
    }

    public void setSessionId(Long sessionId) {
        this.sessionId = sessionId;
    }

    public AttendanceStatus getStatus() {
        return status;
    }

    public void setStatus(AttendanceStatus status) {
        this.status = status;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
