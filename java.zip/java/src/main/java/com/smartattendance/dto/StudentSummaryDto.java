package com.smartattendance.dto;

import java.util.ArrayList;
import java.util.List;

public class StudentSummaryDto {

    private Long studentId;
    private String registerNumber;
    private String name;
    private String department;
    private Integer year;
    private String section;
    private String email;
    private String qrToken;
    private double overallPercentage;
    private long totalSessions;
    private long attendedSessions;
    private List<SubjectAttendanceDto> subjectStats = new ArrayList<>();

    public static class SubjectAttendanceDto {
        private String subjectCode;
        private String subjectName;
        private long totalSessions;
        private long attendedSessions;
        private double percentage;

        public SubjectAttendanceDto() {
        }

        public SubjectAttendanceDto(String subjectCode, String subjectName, long totalSessions, long attendedSessions, double percentage) {
            this.subjectCode = subjectCode;
            this.subjectName = subjectName;
            this.totalSessions = totalSessions;
            this.attendedSessions = attendedSessions;
            this.percentage = percentage;
        }

        public String getSubjectCode() {
            return subjectCode;
        }

        public void setSubjectCode(String subjectCode) {
            this.subjectCode = subjectCode;
        }

        public String getSubjectName() {
            return subjectName;
        }

        public void setSubjectName(String subjectName) {
            this.subjectName = subjectName;
        }

        public long getTotalSessions() {
            return totalSessions;
        }

        public void setTotalSessions(long totalSessions) {
            this.totalSessions = totalSessions;
        }

        public long getAttendedSessions() {
            return attendedSessions;
        }

        public void setAttendedSessions(long attendedSessions) {
            this.attendedSessions = attendedSessions;
        }

        public double getPercentage() {
            return percentage;
        }

        public void setPercentage(double percentage) {
            this.percentage = percentage;
        }
    }

    public StudentSummaryDto() {
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getRegisterNumber() {
        return registerNumber;
    }

    public void setRegisterNumber(String registerNumber) {
        this.registerNumber = registerNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getQrToken() {
        return qrToken;
    }

    public void setQrToken(String qrToken) {
        this.qrToken = qrToken;
    }

    public double getOverallPercentage() {
        return overallPercentage;
    }

    public void setOverallPercentage(double overallPercentage) {
        this.overallPercentage = overallPercentage;
    }

    public long getTotalSessions() {
        return totalSessions;
    }

    public void setTotalSessions(long totalSessions) {
        this.totalSessions = totalSessions;
    }

    public long getAttendedSessions() {
        return attendedSessions;
    }

    public void setAttendedSessions(long attendedSessions) {
        this.attendedSessions = attendedSessions;
    }

    public List<SubjectAttendanceDto> getSubjectStats() {
        return subjectStats;
    }

    public void setSubjectStats(List<SubjectAttendanceDto> subjectStats) {
        this.subjectStats = subjectStats;
    }
}
