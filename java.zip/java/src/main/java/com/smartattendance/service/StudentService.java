package com.smartattendance.service;

import com.smartattendance.model.Student;
import com.smartattendance.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class StudentService {

    private final StudentRepository studentRepository;
    private final QrCodeService qrCodeService;

    public StudentService(StudentRepository studentRepository, QrCodeService qrCodeService) {
        this.studentRepository = studentRepository;
        this.qrCodeService = qrCodeService;
    }

    public Student registerStudent(Student student) {
        if (studentRepository.existsByRegisterNumber(student.getRegisterNumber())) {
            throw new IllegalArgumentException("Register Number '" + student.getRegisterNumber() + "' is already registered.");
        }

        // Generate unique QR token if not provided
        if (student.getQrToken() == null || student.getQrToken().trim().isEmpty()) {
            String token;
            do {
                token = qrCodeService.generateSecureQrToken();
            } while (studentRepository.existsByQrToken(token));
            student.setQrToken(token);
        }

        student.setStatus("ACTIVE");
        student.setCreatedAt(LocalDateTime.now());
        return studentRepository.save(student);
    }

    @Transactional(readOnly = true)
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public Optional<Student> getStudentByRegisterNumber(String regNo) {
        return studentRepository.findByRegisterNumber(regNo);
    }

    @Transactional(readOnly = true)
    public Optional<Student> getStudentByQrToken(String token) {
        return studentRepository.findByQrToken(token);
    }

    @Transactional(readOnly = true)
    public List<Student> getStudentsByDepartment(String department) {
        return studentRepository.findByDepartment(department);
    }

    public Student updateStudent(Long id, Student updated) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Student not found with ID: " + id));

        student.setName(updated.getName());
        student.setDepartment(updated.getDepartment());
        student.setYear(updated.getYear());
        student.setSection(updated.getSection());
        student.setEmail(updated.getEmail());
        if (updated.getStatus() != null) {
            student.setStatus(updated.getStatus());
        }
        return studentRepository.save(student);
    }

    public Student regenerateQrToken(Long id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Student not found with ID: " + id));

        String token;
        do {
            token = qrCodeService.generateSecureQrToken();
        } while (studentRepository.existsByQrToken(token));

        student.setQrToken(token);
        return studentRepository.save(student);
    }

    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public long countTotalStudents() {
        return studentRepository.count();
    }
}
