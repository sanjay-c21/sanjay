package com.smartattendance.service;

import com.smartattendance.model.Subject;
import com.smartattendance.model.Teacher;
import com.smartattendance.repository.SubjectRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class SubjectService {

    private final SubjectRepository subjectRepository;

    public SubjectService(SubjectRepository subjectRepository) {
        this.subjectRepository = subjectRepository;
    }

    public Subject saveSubject(Subject subject) {
        return subjectRepository.save(subject);
    }

    public Subject createSubject(String code, String name, String department, Teacher teacher) {
        if (subjectRepository.existsBySubjectCode(code)) {
            throw new IllegalArgumentException("Subject code " + code + " already exists.");
        }
        Subject subject = new Subject(code, name, department, teacher);
        return subjectRepository.save(subject);
    }

    @Transactional(readOnly = true)
    public List<Subject> getAllSubjects() {
        return subjectRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<Subject> getSubjectById(Long id) {
        return subjectRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public List<Subject> getSubjectsByTeacherId(Long teacherId) {
        return subjectRepository.findByTeacherId(teacherId);
    }

    @Transactional(readOnly = true)
    public List<Subject> getSubjectsByDepartment(String department) {
        return subjectRepository.findByDepartment(department);
    }
}
