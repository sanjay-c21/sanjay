package com.smartattendance.service;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.*;
import com.smartattendance.model.Attendance;
import com.smartattendance.model.AttendanceSession;
import com.smartattendance.model.AttendanceStatus;
import com.smartattendance.model.Student;
import com.smartattendance.repository.AttendanceRepository;
import com.smartattendance.repository.AttendanceSessionRepository;
import com.smartattendance.repository.StudentRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ReportService {

    private final AttendanceSessionRepository sessionRepository;
    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("hh:mm:ss a");
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public ReportService(AttendanceSessionRepository sessionRepository,
                         AttendanceRepository attendanceRepository,
                         StudentRepository studentRepository) {
        this.sessionRepository = sessionRepository;
        this.attendanceRepository = attendanceRepository;
        this.studentRepository = studentRepository;
    }

    /**
     * Export Session Attendance as CSV
     */
    public byte[] generateCsv(Long sessionId) {
        AttendanceSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found: " + sessionId));

        List<Student> students = studentRepository.findByDepartment(session.getSubject().getDepartment());
        if (students.isEmpty()) {
            students = studentRepository.findAll();
        }

        List<Attendance> attendances = attendanceRepository.findBySessionId(sessionId);
        Map<Long, Attendance> attendanceMap = attendances.stream()
                .collect(Collectors.toMap(a -> a.getStudent().getId(), a -> a, (k1, k2) -> k1));

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PrintWriter writer = new PrintWriter(out);

        writer.println("SMART ATTENDANCE SYSTEM - ATTENDANCE REPORT");
        writer.println("Subject," + session.getSubject().getSubjectName() + " (" + session.getSubject().getSubjectCode() + ")");
        writer.println("Teacher," + session.getTeacher().getName());
        writer.println("Date & Time," + session.getStartTime().format(DATE_FMT));
        writer.println("Session Token," + session.getSessionToken());
        writer.println("");
        writer.println("Register No,Student Name,Department,Year,Section,Status,Marked Time,Remarks");

        for (Student student : students) {
            Attendance att = attendanceMap.get(student.getId());
            String status = (att != null) ? att.getStatus().name() : AttendanceStatus.ABSENT.name();
            String time = (att != null) ? att.getMarkedAt().format(TIME_FMT) : "--";
            String remarks = (att != null && att.getRemarks() != null) ? att.getRemarks() : "";

            writer.printf("\"%s\",\"%s\",\"%s\",%d,\"%s\",\"%s\",\"%s\",\"%s\"%n",
                    student.getRegisterNumber(),
                    student.getName(),
                    student.getDepartment(),
                    student.getYear(),
                    student.getSection(),
                    status,
                    time,
                    remarks
            );
        }

        writer.flush();
        return out.toByteArray();
    }

    /**
     * Export Session Attendance as Excel (.xlsx)
     */
    public byte[] generateExcel(Long sessionId) throws Exception {
        AttendanceSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found: " + sessionId));

        List<Student> students = studentRepository.findByDepartment(session.getSubject().getDepartment());
        if (students.isEmpty()) {
            students = studentRepository.findAll();
        }

        List<Attendance> attendances = attendanceRepository.findBySessionId(sessionId);
        Map<Long, Attendance> attendanceMap = attendances.stream()
                .collect(Collectors.toMap(a -> a.getStudent().getId(), a -> a, (k1, k2) -> k1));

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Attendance Report");

            // Header styling
            org.apache.poi.ss.usermodel.Font titleFont = workbook.createFont();
            titleFont.setBold(true);
            titleFont.setFontHeightInPoints((short) 14);
            titleFont.setColor(IndexedColors.DARK_BLUE.getIndex());

            CellStyle titleStyle = workbook.createCellStyle();
            titleStyle.setFont(titleFont);

            org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setColor(IndexedColors.WHITE.getIndex());

            CellStyle headerStyle = workbook.createCellStyle();
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.ROYAL_BLUE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setAlignment(HorizontalAlignment.CENTER);

            // Title rows
            Row r0 = sheet.createRow(0);
            Cell c0 = r0.createCell(0);
            c0.setCellValue("Smart Attendance System - Attendance Report");
            c0.setCellStyle(titleStyle);

            Row r1 = sheet.createRow(1);
            r1.createCell(0).setCellValue("Subject: " + session.getSubject().getSubjectName() + " (" + session.getSubject().getSubjectCode() + ")");
            Row r2 = sheet.createRow(2);
            r2.createCell(0).setCellValue("Teacher: " + session.getTeacher().getName() + " | Date: " + session.getStartTime().format(DATE_FMT));

            // Table headers
            String[] columns = {"S.No", "Register Number", "Student Name", "Department", "Year/Sec", "Status", "Marked Time", "Remarks"};
            Row headerRow = sheet.createRow(4);
            for (int i = 0; i < columns.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerStyle);
            }

            // Data rows
            int rowIdx = 5;
            int sNo = 1;
            for (Student student : students) {
                Row row = sheet.createRow(rowIdx++);
                Attendance att = attendanceMap.get(student.getId());
                boolean isPresent = (att != null && att.getStatus() == AttendanceStatus.PRESENT);

                row.createCell(0).setCellValue(sNo++);
                row.createCell(1).setCellValue(student.getRegisterNumber());
                row.createCell(2).setCellValue(student.getName());
                row.createCell(3).setCellValue(student.getDepartment());
                row.createCell(4).setCellValue(student.getYear() + " / " + student.getSection());

                Cell statusCell = row.createCell(5);
                statusCell.setCellValue(isPresent ? "PRESENT" : "ABSENT");

                row.createCell(6).setCellValue(att != null ? att.getMarkedAt().format(TIME_FMT) : "--");
                row.createCell(7).setCellValue(att != null && att.getRemarks() != null ? att.getRemarks() : "");
            }

            for (int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(out);
            return out.toByteArray();
        }
    }

    /**
     * Export Session Attendance as styled PDF
     */
    public byte[] generatePdf(Long sessionId) throws Exception {
        AttendanceSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found: " + sessionId));

        List<Student> students = studentRepository.findByDepartment(session.getSubject().getDepartment());
        if (students.isEmpty()) {
            students = studentRepository.findAll();
        }

        List<Attendance> attendances = attendanceRepository.findBySessionId(sessionId);
        Map<Long, Attendance> attendanceMap = attendances.stream()
                .collect(Collectors.toMap(a -> a.getStudent().getId(), a -> a, (k1, k2) -> k1));

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4, 36, 36, 36, 36);
        PdfWriter.getInstance(document, out);
        document.open();

        // Fonts
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, new Color(24, 43, 73));
        Font subTitleFont = FontFactory.getFont(FontFactory.HELVETICA, 11, new Color(70, 80, 95));
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.WHITE);
        Font bodyFont = FontFactory.getFont(FontFactory.HELVETICA, 9, Color.DARK_GRAY);
        Font presentFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, new Color(16, 124, 65));
        Font absentFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, new Color(197, 34, 31));

        // Header Section
        Paragraph title = new Paragraph("SMART ATTENDANCE SYSTEM", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);

        Paragraph sub = new Paragraph("Subject: " + session.getSubject().getSubjectName() + " (" + session.getSubject().getSubjectCode() + ") | Teacher: " + session.getTeacher().getName(), subTitleFont);
        sub.setAlignment(Element.ALIGN_CENTER);
        sub.setSpacingAfter(4);
        document.add(sub);

        Paragraph meta = new Paragraph("Session Date: " + session.getStartTime().format(DATE_FMT) + " | Session Code: " + session.getSessionToken(), subTitleFont);
        meta.setAlignment(Element.ALIGN_CENTER);
        meta.setSpacingAfter(15);
        document.add(meta);

        // Stats summary bar
        long presentCount = attendances.stream().filter(a -> a.getStatus() == AttendanceStatus.PRESENT).count();
        long totalCount = students.size();
        double pct = totalCount > 0 ? ((double) presentCount / totalCount) * 100.0 : 0.0;

        Paragraph summary = new Paragraph(String.format("Total Students: %d   |   Present: %d   |   Absent: %d   |   Attendance: %.1f%%",
                totalCount, presentCount, (totalCount - presentCount), pct),
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, new Color(30, 60, 114)));
        summary.setAlignment(Element.ALIGN_CENTER);
        summary.setSpacingAfter(15);
        document.add(summary);

        // Table
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{1.0f, 2.5f, 3.5f, 2.0f, 2.0f, 2.0f});

        String[] headers = {"#", "Reg Number", "Student Name", "Dept", "Status", "Marked Time"};
        for (String h : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(h, headerFont));
            cell.setBackgroundColor(new Color(30, 60, 114));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPadding(6);
            table.addCell(cell);
        }

        int sNo = 1;
        for (Student student : students) {
            Attendance att = attendanceMap.get(student.getId());
            boolean isPresent = (att != null && att.getStatus() == AttendanceStatus.PRESENT);

            PdfPCell c1 = new PdfPCell(new Phrase(String.valueOf(sNo++), bodyFont));
            c1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c1);

            PdfPCell c2 = new PdfPCell(new Phrase(student.getRegisterNumber(), bodyFont));
            table.addCell(c2);

            PdfPCell c3 = new PdfPCell(new Phrase(student.getName(), bodyFont));
            table.addCell(c3);

            PdfPCell c4 = new PdfPCell(new Phrase(student.getDepartment(), bodyFont));
            c4.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c4);

            PdfPCell c5 = new PdfPCell(new Phrase(isPresent ? "PRESENT" : "ABSENT", isPresent ? presentFont : absentFont));
            c5.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c5);

            PdfPCell c6 = new PdfPCell(new Phrase(att != null ? att.getMarkedAt().format(TIME_FMT) : "--", bodyFont));
            c6.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c6);
        }

        document.add(table);
        document.close();

        return out.toByteArray();
    }
}
