package com.smartattendance.service;

import com.smartattendance.dto.AttendanceStatsDto;
import com.smartattendance.dto.ScanResponse;
import com.smartattendance.dto.StudentSummaryDto;
import com.smartattendance.model.*;
import com.smartattendance.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class AttendanceService {

    private final AttendanceSessionRepository sessionRepository;
    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;
    private final SubjectRepository subjectRepository;
    private final TeacherRepository teacherRepository;
    private final QrCodeService qrCodeService;

    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("hh:mm:ss a");
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a");

    public AttendanceService(AttendanceSessionRepository sessionRepository,
                             AttendanceRepository attendanceRepository,
                             StudentRepository studentRepository,
                             SubjectRepository subjectRepository,
                             TeacherRepository teacherRepository,
                             QrCodeService qrCodeService) {
        this.sessionRepository = sessionRepository;
        this.attendanceRepository = attendanceRepository;
        this.studentRepository = studentRepository;
        this.subjectRepository = subjectRepository;
        this.teacherRepository = teacherRepository;
        this.qrCodeService = qrCodeService;
    }

    /**
     * Start a new attendance session
     */
    public AttendanceSession startSession(Long subjectId, Long teacherId, int durationMinutes, String topic) {
        Subject subject = subjectRepository.findById(subjectId)
                .orElseThrow(() -> new IllegalArgumentException("Subject not found: " + subjectId));

        Teacher teacher = teacherRepository.findById(teacherId)
                .orElseThrow(() -> new IllegalArgumentException("Teacher not found: " + teacherId));

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime endTime = now.plusMinutes(durationMinutes > 0 ? durationMinutes : 15);

        String sessionToken = qrCodeService.generateSessionToken();

        AttendanceSession session = new AttendanceSession(subject, teacher, sessionToken, now, endTime, topic);
        return sessionRepository.save(session);
    }

    /**
     * Close an active attendance session
     */
    public AttendanceSession closeSession(Long sessionId) {
        AttendanceSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found: " + sessionId));
        session.setStatus(SessionStatus.CLOSED);
        return sessionRepository.save(session);
    }

    @Transactional(readOnly = true)
    public Optional<AttendanceSession> getSessionById(Long sessionId) {
        return sessionRepository.findById(sessionId);
    }

    @Transactional(readOnly = true)
    public Optional<AttendanceSession> getSessionByToken(String sessionToken) {
        return sessionRepository.findBySessionToken(sessionToken);
    }

    @Transactional(readOnly = true)
    public List<AttendanceSession> getAllSessions() {
        return sessionRepository.findAllByOrderByStartTimeDesc();
    }

    @Transactional(readOnly = true)
    public List<AttendanceSession> getTeacherSessions(Long teacherId) {
        return sessionRepository.findByTeacherIdOrderByStartTimeDesc(teacherId);
    }

    /**
     * Core Anti-Fake / Anti-Proxy Verification Algorithm
     */
    public synchronized ScanResponse markAttendance(String qrToken, String sessionToken, String ipAddress, String userAgent) {
        if (qrToken == null || qrToken.trim().isEmpty()) {
            return ScanResponse.fail("QR Token is missing.", "MISSING_TOKEN");
        }
        if (sessionToken == null || sessionToken.trim().isEmpty()) {
            return ScanResponse.fail("Session Token is missing.", "MISSING_SESSION");
        }

        // 1. Verify Student exists and is active
        Optional<Student> studentOpt = studentRepository.findByQrToken(qrToken.trim());
        if (studentOpt.isEmpty()) {
            return ScanResponse.fail("Invalid QR code. No matching registered student found.", "INVALID_QR_TOKEN");
        }
        Student student = studentOpt.get();
        if (!"ACTIVE".equalsIgnoreCase(student.getStatus())) {
            return ScanResponse.fail("Student profile (" + student.getName() + ") is suspended or inactive.", "STUDENT_INACTIVE");
        }

        // 2. Verify Session exists
        Optional<AttendanceSession> sessionOpt = sessionRepository.findBySessionToken(sessionToken.trim());
        if (sessionOpt.isEmpty()) {
            return ScanResponse.fail("Attendance session not found for token: " + sessionToken, "SESSION_NOT_FOUND");
        }
        AttendanceSession session = sessionOpt.get();

        // 3. Verify Session is active and not expired
        LocalDateTime now = LocalDateTime.now();
        if (session.getStatus() != SessionStatus.ACTIVE || now.isAfter(session.getEndTime())) {
            if (session.getStatus() == SessionStatus.ACTIVE) {
                session.setStatus(SessionStatus.EXPIRED);
                sessionRepository.save(session);
            }
            return ScanResponse.fail("Attendance session has closed or expired. Scans are no longer accepted.", "SESSION_EXPIRED");
        }

        // 4. Anti-Proxy / Duplicate Prevention Check
        if (attendanceRepository.existsByStudentIdAndSessionId(student.getId(), session.getId())) {
            return ScanResponse.fail("Duplicate scan detected! Attendance has ALREADY been recorded for "
                    + student.getName() + " (" + student.getRegisterNumber() + ").", "ALREADY_MARKED");
        }

        // 5. Record verified attendance
        Attendance attendance = new Attendance(
                student,
                session,
                AttendanceStatus.PRESENT,
                ipAddress != null ? ipAddress : "127.0.0.1",
                userAgent != null ? (userAgent.length() > 250 ? userAgent.substring(0, 250) : userAgent) : "Web-Camera-Scanner",
                "Verified via secure QR token scan"
        );
        attendanceRepository.save(attendance);

        String markedTimeStr = attendance.getMarkedAt().format(TIME_FORMATTER);
        return ScanResponse.ok(
                "Attendance marked successfully!",
                student.getName(),
                student.getRegisterNumber(),
                student.getDepartment(),
                session.getSubject().getSubjectName(),
                markedTimeStr,
                AttendanceStatus.PRESENT
        );
    }

    /**
     * Manual attendance status update / override by teacher
     */
    public Attendance updateAttendanceStatus(Long studentId, Long sessionId, AttendanceStatus status, String remarks) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new IllegalArgumentException("Student not found: " + studentId));
        AttendanceSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found: " + sessionId));

        Optional<Attendance> existing = attendanceRepository.findByStudentIdAndSessionId(studentId, sessionId);
        Attendance attendance;
        if (existing.isPresent()) {
            attendance = existing.get();
            attendance.setStatus(status);
            if (remarks != null && !remarks.trim().isEmpty()) {
                attendance.setRemarks(remarks);
            }
        } else {
            attendance = new Attendance(student, session, status, "Teacher-Manual", "Dashboard", remarks != null ? remarks : "Manual teacher entry");
        }
        return attendanceRepository.save(attendance);
    }

    /**
     * Get real-time stats for a session
     */
    @Transactional(readOnly = true)
    public AttendanceStatsDto getSessionStats(Long sessionId) {
        AttendanceSession session = sessionRepository.findById(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found: " + sessionId));

        // Expire if time has passed
        LocalDateTime now = LocalDateTime.now();
        if (session.getStatus() == SessionStatus.ACTIVE && now.isAfter(session.getEndTime())) {
            session.setStatus(SessionStatus.EXPIRED);
            sessionRepository.save(session);
        }

        long presentCount = attendanceRepository.countBySessionIdAndStatus(sessionId, AttendanceStatus.PRESENT);
        long lateCount = attendanceRepository.countBySessionIdAndStatus(sessionId, AttendanceStatus.LATE);
        long totalPresent = presentCount + lateCount;

        // Total enrolled in the subject's department or total registered students
        List<Student> departmentStudents = studentRepository.findByDepartment(session.getSubject().getDepartment());
        long totalEnrolled = departmentStudents.isEmpty() ? studentRepository.count() : departmentStudents.size();
        if (totalEnrolled == 0) {
            totalEnrolled = totalPresent;
        }

        long absentCount = Math.max(0, totalEnrolled - totalPresent);
        double percentage = totalEnrolled > 0 ? ((double) totalPresent / totalEnrolled) * 100.0 : 0.0;

        AttendanceStatsDto dto = new AttendanceStatsDto();
        dto.setSessionId(session.getId());
        dto.setSessionToken(session.getSessionToken());
        dto.setSubjectCode(session.getSubject().getSubjectCode());
        dto.setSubjectName(session.getSubject().getSubjectName());
        dto.setTeacherName(session.getTeacher().getName());
        dto.setTotalStudents(totalEnrolled);
        dto.setPresentCount(totalPresent);
        dto.setAbsentCount(absentCount);
        dto.setAttendancePercentage(Math.round(percentage * 100.0) / 100.0);
        dto.setSessionStatus(session.getStatus().name());
        dto.setStartTime(session.getStartTime().format(DATE_TIME_FORMATTER));
        dto.setEndTime(session.getEndTime().format(DATE_TIME_FORMATTER));

        long secondsRemaining = 0;
        if (session.getStatus() == SessionStatus.ACTIVE && session.getEndTime().isAfter(now)) {
            secondsRemaining = Duration.between(now, session.getEndTime()).getSeconds();
        }
        dto.setSecondsRemaining(secondsRemaining);

        return dto;
    }

    /**
     * Get attendance list for a session
     */
    @Transactional(readOnly = true)
    public List<Attendance> getAttendanceForSession(Long sessionId) {
        return attendanceRepository.findBySessionIdOrderByMarkedAtDesc(sessionId);
    }

    /**
     * Comprehensive Student Attendance Summary with Subject Breakdown
     */
    @Transactional(readOnly = true)
    public StudentSummaryDto getStudentSummary(Long studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new IllegalArgumentException("Student not found: " + studentId));

        StudentSummaryDto summary = new StudentSummaryDto();
        summary.setStudentId(student.getId());
        summary.setRegisterNumber(student.getRegisterNumber());
        summary.setName(student.getName());
        summary.setDepartment(student.getDepartment());
        summary.setYear(student.getYear());
        summary.setSection(student.getSection());
        summary.setEmail(student.getEmail());
        summary.setQrToken(student.getQrToken());

        List<Subject> subjects = subjectRepository.findByDepartment(student.getDepartment());
        if (subjects.isEmpty()) {
            subjects = subjectRepository.findAll();
        }

        long totalCollegeSessions = 0;
        long totalAttendedSessions = 0;
        List<StudentSummaryDto.SubjectAttendanceDto> subjectStatsList = new ArrayList<>();

        for (Subject subject : subjects) {
            long subjectTotalSessions = sessionRepository.countBySubjectId(subject.getId());
            long subjectAttended = attendanceRepository.countByStudentAndSubjectAndStatus(studentId, subject.getId(), AttendanceStatus.PRESENT);

            double pct = subjectTotalSessions > 0 ? ((double) subjectAttended / subjectTotalSessions) * 100.0 : 100.0;

            subjectStatsList.add(new StudentSummaryDto.SubjectAttendanceDto(
                    subject.getSubjectCode(),
                    subject.getSubjectName(),
                    subjectTotalSessions,
                    subjectAttended,
                    Math.round(pct * 10.0) / 10.0
            ));

            totalCollegeSessions += subjectTotalSessions;
            totalAttendedSessions += subjectAttended;
        }

        double overallPct = totalCollegeSessions > 0 ? ((double) totalAttendedSessions / totalCollegeSessions) * 100.0 : 100.0;
        summary.setTotalSessions(totalCollegeSessions);
        summary.setAttendedSessions(totalAttendedSessions);
        summary.setOverallPercentage(Math.round(overallPct * 10.0) / 10.0);
        summary.setSubjectStats(subjectStatsList);

        return summary;
    }
}
