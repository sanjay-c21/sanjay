package com.smartattendance.model;

public enum SessionStatus {
    ACTIVE,
    EXPIRED,
    CLOSED
}
