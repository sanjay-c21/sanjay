package com.smartattendance.config;

import com.smartattendance.model.Attendance;
import com.smartattendance.model.AttendanceSession;
import com.smartattendance.model.AttendanceStatus;
import com.smartattendance.model.Student;
import com.smartattendance.model.Subject;
import com.smartattendance.model.Teacher;
import com.smartattendance.repository.*;
import com.smartattendance.service.QrCodeService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {

    private final TeacherRepository teacherRepository;
    private final SubjectRepository subjectRepository;
    private final StudentRepository studentRepository;
    private final AttendanceSessionRepository sessionRepository;
    private final AttendanceRepository attendanceRepository;
    private final QrCodeService qrCodeService;

    public DataInitializer(TeacherRepository teacherRepository,
                           SubjectRepository subjectRepository,
                           StudentRepository studentRepository,
                           AttendanceSessionRepository sessionRepository,
                           AttendanceRepository attendanceRepository,
                           QrCodeService qrCodeService) {
        this.teacherRepository = teacherRepository;
        this.subjectRepository = subjectRepository;
        this.studentRepository = studentRepository;
        this.sessionRepository = sessionRepository;
        this.attendanceRepository = attendanceRepository;
        this.qrCodeService = qrCodeService;
    }

    @Override
    public void run(String... args) {
        if (teacherRepository.count() > 0) {
            return; // Data already initialized
        }

        System.out.println("Initializing Smart Attendance System with realistic college demo data...");

        // 1. Seed Teachers
        Teacher teacher1 = teacherRepository.save(new Teacher("Dr. Ramesh Kumar", "ramesh@college.edu", "teacher123", "Information Technology"));
        Teacher teacher2 = teacherRepository.save(new Teacher("Prof. Priya Sharma", "priya@college.edu", "teacher123", "Computer Science"));
        Teacher teacher3 = teacherRepository.save(new Teacher("Dr. Anand Verma", "anand@college.edu", "teacher123", "Electronics & Communication"));

        // 2. Seed Subjects
        Subject sub1 = subjectRepository.save(new Subject("IT301", "Java Programming", "Information Technology", teacher1));
        Subject sub2 = subjectRepository.save(new Subject("IT302", "Database Management Systems", "Information Technology", teacher1));
        Subject sub3 = subjectRepository.save(new Subject("CS304", "Computer Networks", "Computer Science", teacher2));
        Subject sub4 = subjectRepository.save(new Subject("CS305", "Operating Systems", "Computer Science", teacher2));
        Subject sub5 = subjectRepository.save(new Subject("EC201", "Digital Signal Processing", "Electronics & Communication", teacher3));

        // 3. Seed Students with unique QR tokens
        Student s1 = studentRepository.save(new Student("23IT101", "Sanjay C", "Information Technology", 3, "A", "sanjay@college.edu", qrCodeService.generateSecureQrToken()));
        Student s2 = studentRepository.save(new Student("23IT102", "Arun Kumar", "Information Technology", 3, "A", "arun@college.edu", qrCodeService.generateSecureQrToken()));
        Student s3 = studentRepository.save(new Student("23IT103", "Kavin Raj", "Information Technology", 3, "A", "kavin@college.edu", qrCodeService.generateSecureQrToken()));
        Student s4 = studentRepository.save(new Student("23IT104", "Divya Bharathi", "Information Technology", 3, "A", "divya@college.edu", qrCodeService.generateSecureQrToken()));
        Student s5 = studentRepository.save(new Student("23IT105", "Manoj Prabakar", "Information Technology", 3, "A", "manoj@college.edu", qrCodeService.generateSecureQrToken()));
        Student s6 = studentRepository.save(new Student("23IT106", "Sneha Reddy", "Information Technology", 3, "B", "sneha@college.edu", qrCodeService.generateSecureQrToken()));
        Student s7 = studentRepository.save(new Student("23CS201", "Rahul Nair", "Computer Science", 2, "A", "rahul@college.edu", qrCodeService.generateSecureQrToken()));
        Student s8 = studentRepository.save(new Student("23CS202", "Ananya Iyer", "Computer Science", 2, "A", "ananya@college.edu", qrCodeService.generateSecureQrToken()));

        // 4. Seed a Past Completed Attendance Session with records
        LocalDateTime pastStart = LocalDateTime.now().minusHours(3);
        AttendanceSession pastSession = new AttendanceSession(sub1, teacher1, qrCodeService.generateSessionToken(), pastStart, pastStart.plusMinutes(45), "Spring Boot Architecture & REST");
        pastSession.setStatus(com.smartattendance.model.SessionStatus.CLOSED);
        pastSession = sessionRepository.save(pastSession);

        attendanceRepository.save(new Attendance(s1, pastSession, AttendanceStatus.PRESENT, "192.168.1.10", "Chrome/Android", "Verified QR"));
        attendanceRepository.save(new Attendance(s2, pastSession, AttendanceStatus.PRESENT, "192.168.1.12", "Safari/iOS", "Verified QR"));
        attendanceRepository.save(new Attendance(s4, pastSession, AttendanceStatus.PRESENT, "192.168.1.15", "Chrome/Android", "Verified QR"));

        // 5. Seed an Active Live Attendance Session (valid for 30 minutes from now) for immediate demo scanning
        LocalDateTime now = LocalDateTime.now();
        AttendanceSession activeSession = new AttendanceSession(sub1, teacher1, qrCodeService.generateSessionToken(), now, now.plusMinutes(30), "Object-Oriented Design & Microservices");
        activeSession = sessionRepository.save(activeSession);

        System.out.println("Data initialization complete! Active session token: " + activeSession.getSessionToken());
    }
}
