// Central API Client for Smart Attendance System
const API_BASE = '/api';

const API = {
    // Students
    async getStudents(dept = '') {
        const url = dept ? `${API_BASE}/students?department=${encodeURIComponent(dept)}` : `${API_BASE}/students`;
        const res = await fetch(url);
        return res.json();
    },

    async getStudentById(id) {
        const res = await fetch(`${API_BASE}/students/${id}`);
        return res.json();
    },

    async getStudentByRegNo(regNo) {
        const res = await fetch(`${API_BASE}/students/by-reg/${encodeURIComponent(regNo)}`);
        return res.json();
    },

    async registerStudent(studentData) {
        const res = await fetch(`${API_BASE}/students`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(studentData)
        });
        if (!res.ok) {
            const err = await res.json();
            throw new Error(err.error || 'Failed to register student');
        }
        return res.json();
    },

    async regenerateQr(id) {
        const res = await fetch(`${API_BASE}/students/${id}/regenerate-qr`, { method: 'POST' });
        return res.json();
    },

    async getStudentQr(id) {
        const res = await fetch(`${API_BASE}/students/${id}/qr`);
        return res.json();
    },

    async getStudentSummary(id) {
        const res = await fetch(`${API_BASE}/students/${id}/summary`);
        return res.json();
    },

    async deleteStudent(id) {
        const res = await fetch(`${API_BASE}/students/${id}`, { method: 'DELETE' });
        return res.json();
    },

    // Teachers & Subjects
    async getTeachers() {
        const res = await fetch(`${API_BASE}/teachers`);
        return res.json();
    },

    async getTeacherSubjects(teacherId) {
        const res = await fetch(`${API_BASE}/teachers/${teacherId}/subjects`);
        return res.json();
    },

    async getTeacherSessions(teacherId) {
        const res = await fetch(`${API_BASE}/teachers/${teacherId}/sessions`);
        return res.json();
    },

    // Attendance Sessions
    async getAllSessions() {
        const res = await fetch(`${API_BASE}/sessions`);
        return res.json();
    },

    async startSession(subjectId, teacherId, durationMinutes, topic) {
        const res = await fetch(`${API_BASE}/sessions/start`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ subjectId, teacherId, durationMinutes, topic })
        });
        if (!res.ok) {
            const err = await res.json();
            throw new Error(err.error || 'Failed to start session');
        }
        return res.json();
    },

    async closeSession(sessionId) {
        const res = await fetch(`${API_BASE}/sessions/${sessionId}/close`, { method: 'POST' });
        return res.json();
    },

    async getSessionStats(sessionId) {
        const res = await fetch(`${API_BASE}/sessions/${sessionId}/stats`);
        return res.json();
    },

    async getSessionQr(sessionId) {
        const res = await fetch(`${API_BASE}/sessions/${sessionId}/qr`);
        return res.json();
    },

    // QR Verification / Attendance Scan
    async scanQr(qrToken, sessionToken) {
        const res = await fetch(`${API_BASE}/attendance/scan`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ qrToken, sessionToken })
        });
        return res.json();
    },

    async getSessionAttendance(sessionId) {
        const res = await fetch(`${API_BASE}/attendance/session/${sessionId}`);
        return res.json();
    },

    async manualAttendance(studentId, sessionId, status, remarks) {
        const res = await fetch(`${API_BASE}/attendance/manual`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ studentId, sessionId, status, remarks })
        });
        return res.json();
    },

    // Admin
    async getAdminStats() {
        const res = await fetch(`${API_BASE}/admin/stats`);
        return res.json();
    },

    async getAllSubjects() {
        const res = await fetch(`${API_BASE}/admin/subjects`);
        return res.json();
    },

    async addSubject(code, name, department, teacherId) {
        const res = await fetch(`${API_BASE}/admin/subjects`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ subjectCode: code, subjectName: name, department, teacherId })
        });
        return res.json();
    }
};

// Toast notification helper
function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : '⚠️';
    toast.innerHTML = `<span>${icon}</span> <div>${message}</div>`;

    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// Audio Feedback (Beep Synthesizer using Web Audio API)
const AudioFeedback = {
    ctx: null,
    init() {
        if (!this.ctx) {
            this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        }
    },
    playSuccess() {
        try {
            this.init();
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(587.33, now); // D5
            osc.frequency.setValueAtTime(880, now + 0.1); // A5

            gain.gain.setValueAtTime(0.15, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

            osc.connect(gain);
            gain.connect(this.ctx.destination);

            osc.start(now);
            osc.stop(now + 0.35);
        } catch (e) {
            console.log('Audio feedback not permitted yet', e);
        }
    },
    playError() {
        try {
            this.init();
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(180, now);
            osc.frequency.setValueAtTime(130, now + 0.15);

            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

            osc.connect(gain);
            gain.connect(this.ctx.destination);

            osc.start(now);
            osc.stop(now + 0.4);
        } catch (e) {
            console.log('Audio feedback error', e);
        }
    }
};
