package com.smartattendance;

import com.smartattendance.dto.ScanResponse;
import com.smartattendance.model.*;
import com.smartattendance.repository.*;
import com.smartattendance.service.AttendanceService;
import com.smartattendance.service.QrCodeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AttendanceServiceTest {

    @Mock private AttendanceSessionRepository sessionRepository;
    @Mock private AttendanceRepository attendanceRepository;
    @Mock private StudentRepository studentRepository;
    @Mock private SubjectRepository subjectRepository;
    @Mock private TeacherRepository teacherRepository;
    @Mock private QrCodeService qrCodeService;

    private AttendanceService attendanceService;

    private Student testStudent;
    private AttendanceSession testSession;
    private Subject testSubject;
    private Teacher testTeacher;

    @BeforeEach
    void setUp() {
        attendanceService = new AttendanceService(
                sessionRepository, attendanceRepository, studentRepository,
                subjectRepository, teacherRepository, qrCodeService
        );

        testTeacher = new Teacher("Dr. Ramesh", "ramesh@college.edu", "pass", "IT");
        testTeacher.setId(1L);

        testSubject = new Subject("IT301", "Java Programming", "IT", testTeacher);
        testSubject.setId(1L);

        testStudent = new Student("23IT101", "Sanjay C", "IT", 3, "A", "sanjay@college.edu", "STU-AAAA-1111");
        testStudent.setId(10L);

        testSession = new AttendanceSession(
                testSubject, testTeacher, "SESS-BBBB-2222",
                LocalDateTime.now().minusMinutes(5),
                LocalDateTime.now().plusMinutes(25),
                "OOP Concepts"
        );
        testSession.setId(100L);
    }

    @Test
    void testSuccessfulAttendanceVerification() {
        when(studentRepository.findByQrToken("STU-AAAA-1111")).thenReturn(Optional.of(testStudent));
        when(sessionRepository.findBySessionToken("SESS-BBBB-2222")).thenReturn(Optional.of(testSession));
        when(attendanceRepository.existsByStudentIdAndSessionId(10L, 100L)).thenReturn(false);

        ScanResponse response = attendanceService.markAttendance(
                "STU-AAAA-1111", "SESS-BBBB-2222", "192.168.1.50", "Test-Device"
        );

        assertTrue(response.isSuccess());
        assertEquals("Sanjay C", response.getStudentName());
        assertEquals("23IT101", response.getRegisterNumber());
        assertEquals(AttendanceStatus.PRESENT, response.getStatus());

        verify(attendanceRepository, times(1)).save(any(Attendance.class));
    }

    @Test
    void testAntiDuplicateVerificationPreventsMultipleScans() {
        when(studentRepository.findByQrToken("STU-AAAA-1111")).thenReturn(Optional.of(testStudent));
        when(sessionRepository.findBySessionToken("SESS-BBBB-2222")).thenReturn(Optional.of(testSession));
        // Simulate attendance already marked previously
        when(attendanceRepository.existsByStudentIdAndSessionId(10L, 100L)).thenReturn(true);

        ScanResponse response = attendanceService.markAttendance(
                "STU-AAAA-1111", "SESS-BBBB-2222", "192.168.1.50", "Test-Device"
        );

        assertFalse(response.isSuccess());
        assertEquals("ALREADY_MARKED", response.getErrorCode());
        assertTrue(response.getMessage().contains("Duplicate scan detected"));

        verify(attendanceRepository, never()).save(any(Attendance.class));
    }

    @Test
    void testExpiredSessionRejection() {
        // Session ended in the past
        testSession.setEndTime(LocalDateTime.now().minusMinutes(10));

        when(studentRepository.findByQrToken("STU-AAAA-1111")).thenReturn(Optional.of(testStudent));
        when(sessionRepository.findBySessionToken("SESS-BBBB-2222")).thenReturn(Optional.of(testSession));

        ScanResponse response = attendanceService.markAttendance(
                "STU-AAAA-1111", "SESS-BBBB-2222", "192.168.1.50", "Test-Device"
        );

        assertFalse(response.isSuccess());
        assertEquals("SESSION_EXPIRED", response.getErrorCode());
        verify(attendanceRepository, never()).save(any(Attendance.class));
    }

    @Test
    void testInvalidQrTokenRejection() {
        when(studentRepository.findByQrToken("INVALID-TOKEN")).thenReturn(Optional.empty());

        ScanResponse response = attendanceService.markAttendance(
                "INVALID-TOKEN", "SESS-BBBB-2222", "192.168.1.50", "Test-Device"
        );

        assertFalse(response.isSuccess());
        assertEquals("INVALID_QR_TOKEN", response.getErrorCode());
    }
}
