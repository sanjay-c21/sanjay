package com.smartattendance;

import com.smartattendance.service.QrCodeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class QrCodeServiceTest {

    private QrCodeService qrCodeService;

    @BeforeEach
    void setUp() {
        qrCodeService = new QrCodeService();
    }

    @Test
    void testGenerateSecureQrToken() {
        String token1 = qrCodeService.generateSecureQrToken();
        String token2 = qrCodeService.generateSecureQrToken();

        assertNotNull(token1);
        assertNotNull(token2);
        assertNotEquals(token1, token2);
        assertTrue(token1.startsWith("STU-"));
        assertEquals(13, token1.length()); // STU-XXXX-XXXX
    }

    @Test
    void testGenerateSessionToken() {
        String sessionToken = qrCodeService.generateSessionToken();

        assertNotNull(sessionToken);
        assertTrue(sessionToken.startsWith("SESS-"));
        assertEquals(14, sessionToken.length()); // SESS-XXXX-XXXX
    }

    @Test
    void testGenerateQrPng() throws Exception {
        byte[] png = qrCodeService.generateQrCodePng("STU-TEST-1234", 200, 200);

        assertNotNull(png);
        assertTrue(png.length > 0);
        // Check PNG magic bytes (0x89, 'P', 'N', 'G')
        assertEquals((byte) 0x89, png[0]);
        assertEquals((byte) 0x50, png[1]);
        assertEquals((byte) 0x4E, png[2]);
        assertEquals((byte) 0x47, png[3]);
    }

    @Test
    void testGenerateQrBase64() {
        String base64 = qrCodeService.generateQrCodeBase64("STU-TEST-1234", 200, 200);

        assertNotNull(base64);
        assertTrue(base64.startsWith("data:image/png;base64,"));
        assertTrue(base64.length() > 50);
    }
}
