@echo off
setlocal
echo ===================================================
echo   Smart Attendance System with QR Code (MySQL Mode)
echo ===================================================

set "JAVA_HOME=%USERPROFILE%\.tools\jdk-17.0.10+7"
set "MAVEN_HOME=%USERPROFILE%\.tools\apache-maven-3.9.6"
set "PATH=%JAVA_HOME%\bin;%MAVEN_HOME%\bin;%PATH%"

set /p DB_USER=Enter MySQL Username (default root): 
if "%DB_USER%"=="" set DB_USER=root

set /p DB_PASS=Enter MySQL Password (default root): 
if "%DB_PASS%"=="" set DB_PASS=root

echo Launching with MySQL profile...
mvn spring-boot:run -Dspring-boot.run.profiles=mysql -Dspring-boot.run.arguments="--spring.datasource.username=%DB_USER% --spring.datasource.password=%DB_PASS%"

pause
