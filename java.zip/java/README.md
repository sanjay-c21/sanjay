# Smart Attendance System with QR Code 🎓⚡

A modern, production-grade Java and Spring Boot web application for automated college attendance tracking using unique student QR codes, live camera scanning, anti-proxy verification, real-time teacher dashboards, and exportable reports (CSV, Excel, PDF).

---

## 🌟 Key Features

1. **Unique Student QR Tokens**
   - Cryptographically random unique tokens (`STU-XXXX-XXXX`) generated for every student upon registration.
   - High-resolution QR codes generated dynamically using Google **ZXing**.
   - Accessible via Digital ID Card interface with download and print options.

2. **Strict Anti-Fake / Anti-Proxy Mechanism**
   - **Time-Limited Sessions**: Sessions automatically close or expire after the instructor's configured duration (e.g., 5, 10, 15, or 30 mins).
   - **Single Scan Enforcement**: Atomic database-level and service-level checks (`(student_id, session_id)` unique constraint) reject duplicate scans instantly.
   - **Audit Logging**: Every scan records exact timestamp, client IP, and device user-agent.

3. **Live Camera & Kiosk QR Scanner**
   - Real-time mobile or webcam QR scanning powered by `html5-qrcode`.
   - Web Audio API synthesizer gives instant positive chime for success and error buzz for duplicate/expired scans.
   - Instant visual feedback banner with animations and live feed history.
   - Built-in one-click demo student tokens for easy presentation testing without requiring camera hardware.

4. **Interactive Teacher Cockpit**
   - Select subject and launch time-limited sessions with countdown timer.
   - Live KPI counters: Total Students, Present (Green), Absent (Red), Attendance Rate (%).
   - Live student verification table updating in real time.
   - Manual attendance override/adjustment modal.
   - Projector mode: Display high-res session QR on projector screen for classroom scanning.

5. **Student Portal & Digital ID Card**
   - Digital student ID card styled with college badge and embedded ZXing QR code.
   - Overall attendance gauge with college exam eligibility status (>= 75% threshold).
   - Subject-wise attendance breakdown cards with progress bars and shortage alerts.

6. **Comprehensive Reports & Data Export**
   - **CSV Export**: Clean comma-separated attendance log.
   - **Excel (.xlsx) Export**: Professional spreadsheet styled with Apache POI, headers, and color-coded statuses.
   - **PDF Export**: Official printable attendance sheet generated via OpenPDF with college header, statistics bar, and student roster table.

7. **Admin Management Suite**
   - Enroll new students with auto QR token generation.
   - Security QR token regeneration (invalidates compromised/leaked QR codes).
   - Manage subjects and assign faculty.
   - College-wide attendance metrics.

---

## 🏗️ Technology Stack

| Component | Technology |
|---|---|
| **Backend Language** | Java 17 (Microsoft OpenJDK / Eclipse Temurin) |
| **Framework** | Spring Boot 3.2.3 (REST APIs, Spring Data JPA, Hibernate) |
| **Databases** | **MySQL 8.0** & **H2 Database** (Zero-config persistent demo mode) |
| **QR Generation** | Google ZXing (`core` & `javase` 3.5.3) |
| **QR Scanning** | HTML5 Camera Stream via `html5-qrcode` |
| **Report Engine** | Apache POI (Excel) & OpenPDF (PDF) |
| **Frontend** | Vanilla HTML5, Modern CSS (Glassmorphism, Dark Theme, Outfit/Inter typography), JavaScript ES6 |
| **Build Tool** | Apache Maven 3.9.6 |

---

## 📁 Project Structure

```text
SmartAttendance/
├── src/
│   ├── main/
│   │   ├── java/com/smartattendance/
│   │   │   ├── config/
│   │   │   │   ├── DataInitializer.java        # Pre-populates realistic college demo data
│   │   │   │   └── WebConfig.java              # CORS & web MVC configuration
│   │   │   ├── controller/
│   │   │   │   ├── AdminController.java         # System metrics, subject/faculty setup
│   │   │   │   ├── AttendanceController.java    # Anti-proxy QR verification & manual edits
│   │   │   │   ├── AttendanceSessionController.java # Start/close sessions, stats, session QR
│   │   │   │   ├── ReportController.java        # CSV, Excel, and PDF downloads
│   │   │   │   ├── StudentController.java       # Student CRUD, QR image, summary analytics
│   │   │   │   └── TeacherController.java       # Teacher auth, subjects, and sessions
│   │   │   ├── dto/
│   │   │   │   ├── AttendanceStatsDto.java      # Real-time session KPI payload
│   │   │   │   ├── ManualAttendanceDto.java     # Teacher override payload
│   │   │   │   ├── ScanRequest.java             # QR Token + Session Token scan request
│   │   │   │   ├── ScanResponse.java            # Verification result payload
│   │   │   │   ├── SessionCreateRequest.java    # New session parameters
│   │   │   │   └── StudentSummaryDto.java       # Subject-by-subject attendance analytics
│   │   │   ├── model/
│   │   │   │   ├── Attendance.java              # Attendance record with unique constraint
│   │   │   │   ├── AttendanceSession.java       # Time-limited session entity
│   │   │   │   ├── AttendanceStatus.java        # PRESENT, ABSENT, LATE
│   │   │   │   ├── SessionStatus.java           # ACTIVE, EXPIRED, CLOSED
│   │   │   │   ├── Student.java                 # Student entity with unique QR token
│   │   │   │   ├── Subject.java                 # Academic course/subject entity
│   │   │   │   └── Teacher.java                 # Faculty profile entity
│   │   │   ├── repository/
│   │   │   │   ├── AttendanceRepository.java
│   │   │   │   ├── AttendanceSessionRepository.java
│   │   │   │   ├── StudentRepository.java
│   │   │   │   ├── SubjectRepository.java
│   │   │   │   └── TeacherRepository.java
│   │   │   ├── service/
│   │   │   │   ├── AttendanceService.java       # Core anti-proxy verification engine
│   │   │   │   ├── QrCodeService.java           # ZXing high-res QR rendering
│   │   │   │   ├── ReportService.java           # CSV, Excel POI, and OpenPDF generators
│   │   │   │   ├── StudentService.java
│   │   │   │   ├── SubjectService.java
│   │   │   │   └── TeacherService.java
│   │   │   └── SmartAttendanceApplication.java  # Main application entry point
│   │   └── resources/
│   │       ├── static/
│   │       │   ├── css/style.css                # Polished glassmorphism design system
│   │       │   ├── js/api.js                    # API client, audio synthesizer, toast alerts
│   │       │   ├── index.html                   # Landing portal gateway
│   │       │   ├── teacher.html                 # Teacher live cockpit & report exports
│   │       │   ├── student.html                 # Digital student ID card & attendance stats
│   │       │   ├── scanner.html                 # Live camera QR scanner with audio cues
│   │       │   └── admin.html                   # Admin management console
│   │       ├── application.properties           # Main configuration
│   │       ├── application-dev.properties       # Zero-config embedded persistent database
│   │       └── application-mysql.properties     # Production MySQL 8.0 configuration
│   └── test/
│       └── java/com/smartattendance/
│           ├── AttendanceServiceTest.java       # Anti-proxy verification unit tests
│           └── QrCodeServiceTest.java           # ZXing QR generation unit tests
├── run.bat                                      # One-click launch script
├── run-mysql.bat                                # One-click launch with local MySQL Server
├── pom.xml                                      # Maven project descriptor
└── README.md
```

---

## 🚀 Quick Start Guide

### Option 1: One-Click Instant Launch (Recommended for Demo)
Double click `run.bat` or run in terminal:
```bash
run.bat
```
This starts the application on **`http://localhost:8080`** using the persistent embedded database. Realistic sample faculty (Dr. Ramesh, Prof. Priya), subjects (Java, DBMS, Networks), and students with pre-generated QR codes are automatically initialized on first run!

### Option 2: Run with MySQL 8.0
1. Ensure your MySQL service (`MySQL80`) is running.
2. Run `run-mysql.bat`:
```bash
run-mysql.bat
```
3. Enter your MySQL username (default: `root`) and password when prompted. The application will automatically create the `smart_attendance` database and tables.

---

## 📱 User Flows

### 1. Student Workflow
1. Navigate to **Student Portal** (`http://localhost:8080/student.html`).
2. Select any student (e.g. `23IT101 - Sanjay C`).
3. View the **Digital ID Card** with your unique QR code.
4. Click **Download QR** or **Print ID Card**.
5. View your overall attendance percentage and per-subject attendance tracking.

### 2. Teacher Workflow
1. Navigate to **Teacher Portal** (`http://localhost:8080/teacher.html`).
2. Click **Start New Session**, pick **Java Programming (IT301)**, set duration (e.g., 15 minutes), and submit.
3. The live attendance cockpit appears with a countdown timer and live stats.
4. Click **Project QR** to project the classroom QR code on screen, or open the **Scanner**.
5. Watch students appear live on the attendance roster as their QR codes are verified.
6. Click **Export Excel**, **Export CSV**, or **Export PDF** to generate reports.

### 3. Scanner Workflow
1. Navigate to **Live Scanner** (`http://localhost:8080/scanner.html`).
2. Select the active classroom session.
3. Point your camera at a student QR code, or click any of the **Quick Click Sample Students** buttons.
4. If valid: The system plays a **positive chime**, turns green, and records attendance.
5. If scanned again: The anti-proxy engine immediately blocks it, triggers an **error buzz**, turns red, and reports **`Duplicate scan detected!`**.

---

## 🔒 Anti-Proxy Security Design

```text
Student Scans QR
       │
       ▼
[Backend QR Token Lookup] ──(Not Found / Inactive)──► REJECT: INVALID_QR_TOKEN
       │ (Valid Student)
       ▼
[Session Lookup & Expiration Check] ──(Expired/Closed)──► REJECT: SESSION_EXPIRED
       │ (Session Active)
       ▼
[Atomic Database Duplicate Check] ──(Already Marked)──► REJECT: ALREADY_MARKED (Duplicate Scan Blocked!)
       │ (First Time This Session)
       ▼
[Save Attendance Record: Student + Session + Timestamp + IP + UserAgent]
       │
       ▼
SUCCESS: Marked PRESENT (Audio Chime + Live Dashboard Auto-Update)
```
