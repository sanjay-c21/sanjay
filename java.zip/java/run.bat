@echo off
setlocal
echo ===================================================
echo   Smart Attendance System with QR Code
echo   Starting Spring Boot Application...
echo ===================================================

set "JAVA_HOME=%USERPROFILE%\.tools\jdk-17.0.10+7"
set "MAVEN_HOME=%USERPROFILE%\.tools\apache-maven-3.9.6"
set "PATH=%JAVA_HOME%\bin;%MAVEN_HOME%\bin;%PATH%"

echo Java Version:
java -version

echo.
echo Launching Application on http://localhost:8080 ...
mvn spring-boot:run

pause
